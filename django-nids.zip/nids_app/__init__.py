# NIDS App initialization
